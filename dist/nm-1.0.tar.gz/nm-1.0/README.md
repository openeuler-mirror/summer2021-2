# nm
Nm is a system monitor, and it will send out alarm information
## Features
## build
```make```
## install
```make install```
